import kivy
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.gridlayout import GridLayout
from kivy.uix.widget import Widget
from kivy.properties import ObjectProperty
import tkinter as tk
import pygame
from pygame import mixer
import math
import turtle
import time
import random
import requests
from tkinter import *

class MainWindow(Screen):
    pass

class SecondWindow(Screen):
    game = ObjectProperty(None)

    def btn(self):
        import random
        choices = ["hangman", "7 Up 7 Down Game", "Pong"]
        games = random.choice(choices)
        print(games)
        if games == "hangman":
            WIDTH, HEIGHT = 800, 500

            # Initialize pygame
            pygame.init()

            # Setting up the display
            win = pygame.display.set_mode((WIDTH, HEIGHT))
            pygame.display.set_caption("Hangman Game Made By Yash")

            # Button variables
            RADIUS = 20
            GAP = 15
            letters = []
            startx = round((WIDTH - (RADIUS * 2 + GAP) * 13) / 2)
            starty = 400

            A = 65

            # Fonts
            LETTER_FONT = pygame.font.SysFont('comicsans', 40)
            WORD_FONT = pygame.font.SysFont('comicsans', 60)
            TITLE_FONT = pygame.font.SysFont('comicsans', 70)

            for i in range(26):
                x = startx + GAP * 2 + ((RADIUS * 2 + GAP) * (i % 13))
                y = starty + ((i // 13) * (GAP + RADIUS * 2))
                letters.append([x, y, chr(A + i), True])
            # Game variables
            hangman_status = 0
            word = "DEVELOPER"
            guessed = []

            # Colours for the background
            WHITE = (255, 255, 255)
            BLACK = (0, 0, 0)

            # Set up the game loop
            FPS = 60
            clock = pygame.time.Clock()
            run = True

            def draw():
                win.fill(WHITE)
                # Drawing the message
                text = TITLE_FONT.render("I MAKE THINGS WHO AM I???", 1, BLACK)
                win.blit(text, (WIDTH / 2 - text.get_width() / 2, 20))

                # Draw word
                display_word = ""
                for letter in word:
                    if letter in guessed:
                        display_word += letter + " "
                    else:
                        display_word += "_ "
                text = WORD_FONT.render(display_word, 1, BLACK)
                win.blit(text, (400, 200))

                # Draw button
                for letter in letters:
                    x, y, ltr, visible = letter
                    if visible:
                        pygame.draw.circle(win, BLACK, (x, y), RADIUS, 3)
                        text = LETTER_FONT.render(ltr, 1, BLACK)
                        win.blit(text, (x - text.get_width() / 2, y - text.get_height() / 2))

                win.blit(images[hangman_status], (150, 100))
                pygame.display.update()

            # display_message("YOU WON!!!")
            def display_message(message):
                pygame.time.delay(1000)
                win.fill(WHITE)
                text = WORD_FONT.render(message, 1, BLACK)
                win.blit(text, (WIDTH / 2 - text.get_width() / 2, HEIGHT / 2 - text.get_height() / 2))
                pygame.display.update()
                pygame.time.delay(3000)

            # Loading the images
            images = []
            for i in range(7):
                image = pygame.image.load("hangman" + str(i) + ".png")
                images.append(image)

            # print(images)

            while run:
                clock.tick(FPS)

                draw()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        run = False

                    if event.type == pygame.MOUSEBUTTONDOWN:
                        m_x, m_y = pygame.mouse.get_pos()
                        # print(pos)
                        for letter in letters:
                            x, y, ltr, visible = letter
                            if visible:
                                dis = math.sqrt((x - m_x) ** 2 + (y - m_y) ** 2)
                                if dis < RADIUS:
                                    # print(ltr)
                                    letter[3] = False
                                    guessed.append(ltr)

                                    if ltr not in word:
                                        hangman_status += 1

                won = True
                for letter in word:
                    if letter not in guessed:
                        won = False
                        break

                if won:
                    '''win.fill(WHITE)
                    text = WORD_FONT.render("YOU WON!!!",1,BLACK)
                    win.blit(text,(WIDTH/2 - text.get_width()/2, HEIGHT/2 - text.get_height()/2))
                    pygame.display.update()
                    pygame.time.delay(3000)'''
                    display_message("YOU WON!!!")
                    break

                if hangman_status == 6:
                    # print("You Lost")
                    # time.sleep(1)
                    display_message("YOU LOST!!!")
                    break

            pygame.quit()

        if games == "7 Up 7 Down Game":
            import tkinter as tk
            import random

            HEIGHT = 600
            WIDTH = 600

            possibility1 = 2, 6
            possibilty2 = 7
            possibility3 = 8, 12

            heading1 = 2 - 6
            heading2 = 7
            heading3 = 8 - 12

            score = 0

            def test_function(entry):
                print("The button was clicked")

            def roll_dice(entry):
                heading = 2, 12
                heading = random.randint(2, 12)
                label['text'] = heading

            def get_score(entry):
                score = 0
                heading = 2, 12
                heading = random.randint(2, 12)
                if entry == 2 and heading == entry:
                    print(score)
                    score += 10
                    print(score)

            root = tk.Tk()

            canvas = tk.Canvas(root, height=HEIGHT, width=WIDTH)
            canvas.pack()

            '''background_image=tk.PhotoImage(file='B DAY.png')
            background_label=tk.Label(root,image=background_image)
            background_label.place(relwidth=1,relheight=1)'''

            frame = tk.Frame(root, bg='red', bd=5)
            frame.place(relx=0.5, rely=0.1, relwidth=0.75, relheight=0.1, anchor='n')

            entry = tk.Entry(frame, font=100, justify='center')
            entry.place(relwidth=0.65, relheight=1)

            button = tk.Button(frame, bg='white', text='ROLL DICE', command=lambda: roll_dice(entry.get()))
            button.place(relx=0.7, relwidth=0.3, relheight=1)

            lower_frame = tk.Frame(root, bg='red', bd=5)
            lower_frame.place(relx=0.5, rely=0.25, relwidth=0.75, relheight=0.6, anchor='n')

            label = tk.Label(lower_frame, bg='white')
            label.place(relwidth=1, relheight=1)

            print(get_score)

            root.mainloop()

        if games == "Pong":

            from tkinter import ttk, colorchooser, filedialog
            import PIL
            from PIL import ImageGrab

            class main:
                def __init__(self, master):
                    self.master = master
                    self.color_fg = 'black'
                    self.color_bg = 'white'
                    self.old_x = None
                    self.old_y = None
                    self.penwidth = 5
                    self.drawWidgets()
                    self.c.bind('<B1-Motion>', self.paint)
                    self.c.bind('<ButtonRelease-1>', self.reset)

                def paint(self, e):
                    if self.old_x and self.old_y:
                        self.c.create_line(self.old_x, self.old_y, e.x, e.y, width=self.penwidth, fill=self.color_fg,
                                           capstyle=ROUND, smooth=True)
                    self.old_x = e.x
                    self.old_y = e.y

                def reset(self, e):
                    self.old_x = None
                    self.old_y = None

                def changeW(self, e):
                    self.penwidth = e

                def save(self):
                    file = filedialog.asksaveasfilename(filetypes=[('Portable Network Graphics', '*.png')])
                    if file:
                        x = self.master.winfo_rootx() + self.c.winfo_x()
                        y = self.master.winfo_rooty() + self.c.winfo_y()
                        x1 = self.master.winfo_width()
                        y1 = self.master.winfo_height()

                        PIL.ImageGrab.grab().crop((x, y, x1, y1)).save(file + '.png')

                def clear(self):
                    self.c.delete(ALL)

                def change_fg(self):
                    self.color_fg = colorchooser.askcolor(color=self.color_fg)[1]

                def change_bg(self):
                    self.color_bg = colorchooser.askcolor(color=self.color_bg)[1]
                    self.c['bg'] = self.color_bg

                def drawWidgets(self):

                    self.controls = Frame(self.master, padx=5, pady=5)
                    Label(self.controls, text='Pen Width', font='Arial').grid(row=0, column=0)
                    self.slider = ttk.Scale(self.controls, from_=5, to=100, command=self.changeW, orient=HORIZONTAL)

                    self.slider.set(self.penwidth)

                    self.slider.grid(row=0, column=1, ipadx=30)

                    self.controls.pack()

                    self.c = Canvas(self.master, width=500, height=400, bg=self.color_bg)
                    self.c.pack(fill=BOTH, expand=True)

                    menu = Menu(self.master)
                    self.master.config(menu=menu)
                    filemenu = Menu(menu)
                    menu.add_cascade(label='File..', menu=filemenu)
                    filemenu.add_command(label='Export..', command=self.save)
                    colormenu = Menu(menu)
                    menu.add_cascade(label='Colors', menu=colormenu)
                    colormenu.add_command(label='Brush Color..', command=self.change_fg)
                    colormenu.add_command(label='Background Color..', command=self.change_bg)
                    optionmenu = Menu(menu)
                    menu.add_cascade(label='Options', menu=optionmenu)
                    optionmenu.add_command(label='Remove Color', command=self.clear)
                    optionmenu.add_command(label='Exit', command=self.master.destroy)

            if __name__ == '__main__':
                root2 = Tk()
                main(root2)
                root2.title('Drawing app made by Yash Solanki')
                root2.mainloop()

class ThirdWindow(Screen):
    pass

class WindowManager(ScreenManager):
    pass

kv = Builder.load_file("my.kv")

class MyGrid(Widget):
    pass

class MyApp(App):
    def build(self):

        return kv

if __name__ == "__main__":
    MyApp().run()